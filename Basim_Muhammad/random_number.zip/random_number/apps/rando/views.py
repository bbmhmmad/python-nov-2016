from django.shortcuts import render,redirect
import string
import random

count=1
def index(request):
	rando=''.join(random.choice(string.lowercase) for i in range(8))
	number={'random_number':rando}
	return render(request, 'index.html',number)
# Create your views here.

def refresh(request):
	if request.method=='POST':
		request.session['count']+=1
		return redirect('/')
	else:
		return redirect('/')


