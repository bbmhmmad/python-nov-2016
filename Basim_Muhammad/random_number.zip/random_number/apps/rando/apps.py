from __future__ import unicode_literals

from django.apps import AppConfig


class RandoConfig(AppConfig):
    name = 'rando'
