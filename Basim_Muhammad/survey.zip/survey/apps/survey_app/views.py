from django.shortcuts import render,redirect

def index(request):
	return render (request,'index.html')


def process(request):
	if request.method=='POST':
		request.session['name']=request.POST['name']
		request.session['location']=request.POST['location']
		request.session['language']=request.POST['language']
		request.session['comment']=request.POST['comment']
		if 'count' in request.session:
			request.session['count']+=1
		else:
			request.session['count']=1
		return redirect('/results')
	else:
		return redirect('/')


def results(request):
	data={'user_name':request.session['name'], 'user_location':request.session['location'],'user_language':request.session['language'],'user_comment':request.session['comment'],'counter':request.session['count']}
	return render(request,'results.html',data)

# Create your views here.
